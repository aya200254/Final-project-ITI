export interface Category {
  id?: number;
  name: string;
  desc: string;
  image: any;
}
