export interface Inventory {
    id?: number
    quantity: number
}
