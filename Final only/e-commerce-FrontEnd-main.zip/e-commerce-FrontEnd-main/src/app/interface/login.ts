export interface Login {
  id?: number;
  email: string;
  password: string;
}
