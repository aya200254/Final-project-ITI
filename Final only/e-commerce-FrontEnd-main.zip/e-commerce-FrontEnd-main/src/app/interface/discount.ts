export interface Discount {
  id?: number
  name: string
  desc: string
  percent: number
  active: boolean
}
